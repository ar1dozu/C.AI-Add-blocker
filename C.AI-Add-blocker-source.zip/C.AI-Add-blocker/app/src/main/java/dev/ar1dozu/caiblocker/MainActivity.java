package dev.ar1dozu.caiblocker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setGravity(Gravity.TOP);
        root.setBackgroundColor(0xFF101418);

        TextView title = new TextView(this);
        title.setText("C.AI Add-blocker");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        TextView body = new TextView(this);
        body.setText("Prototype 0.1.0\n\nTarget: ai.character.app\nFramework: LSPosed / Xposed API 82\n\nEnable this module in LSPosed and select Character.AI in Scope.\n\nThis prototype hides selected native ad-view classes. It may not catch every ad placement.");
        body.setTextColor(0xFFE3E8ED);
        body.setTextSize(16);
        body.setLineSpacing(dp(4), 1.0f);
        body.setPadding(0, dp(20), 0, 0);

        root.addView(title);
        root.addView(body);
        setContentView(root);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
