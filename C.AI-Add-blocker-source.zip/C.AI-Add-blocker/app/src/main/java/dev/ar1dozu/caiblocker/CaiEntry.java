package dev.ar1dozu.caiblocker;

import android.view.View;
import android.view.ViewGroup;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class CaiEntry implements IXposedHookLoadPackage {
    private static final String TAG = "[C.AI Add-blocker] ";
    private static final String TARGET = "ai.character.app";

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p) {
        if (!TARGET.equals(p.packageName)) return;
        XposedBridge.log(TAG + "loaded in " + p.processName);

        // Observe views only after they enter the hierarchy. Match specific ad SDK view names
        // found in the provided APK; do not disable SDK initialization or networking globally.
        XposedHelpers.findAndHookMethod(ViewGroup.class, "addView", View.class,
            new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    View child = (View) param.args[0];
                    if (child == null) return;
                    if (isKnownAdView(child.getClass())) {
                        child.setVisibility(View.GONE);
                        child.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                        XposedBridge.log(TAG + "hidden ad view: " + child.getClass().getName());
                    }
                }
            });
    }

    private static boolean isKnownAdView(Class<?> type) {
        for (Class<?> c = type; c != null; c = c.getSuperclass()) {
            String name = c.getName();
            if (name.equals("com.simulaads.reactnative.SimulaNativeAdView")
                    || name.equals("com.cloudxreactnative.CloudXAdView")
                    || name.equals("io.cloudx.sdk.CloudXAdView")
                    || name.equals("io.cloudx.sdk.CloudXNativeAdView")) {
                return true;
            }
        }
        return false;
    }
}
