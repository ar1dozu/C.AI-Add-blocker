# C.AI Add-blocker

Experimental LSPosed module for Character.AI Android (`ai.character.app`).

## Prototype status

This first prototype targets known ad-view class names observed in the supplied Character.AI APK: Simula Ads / CloudX integration. It hides matching native ad views when they are added to a view hierarchy. This is best-effort UI filtering, not a guarantee that every ad request or placement is blocked. Some placements may use different class names or WebView content.

## Build

GitHub Actions builds a debug APK on pushes to `main` and on manual dispatch. Open **Actions → Build Android module**, then download the `C-AI-Add-blocker-debug-apk` artifact from a successful run.

## Enable

1. Install the debug APK.
2. In LSPosed → Modules, enable **C.AI Add-blocker**.
3. In Scope, select only Character.AI (`ai.character.app`).
4. Force-stop and reopen Character.AI.

If anything behaves incorrectly, disable the module in LSPosed and force-stop Character.AI.

## Technical

- Package: `dev.ar1dozu.caiblocker`
- Target: `ai.character.app`
- LSPosed/Xposed legacy API: 82
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17

This is an experimental community module. It does not modify Character.AI's APK or alter account/subscription entitlements.
